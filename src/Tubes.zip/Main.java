import form.LandingPage;

public class Main {
    public static void main(String[] args) {
        LandingPage landingPage = new LandingPage();


    }
}